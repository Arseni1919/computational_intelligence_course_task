# from CONSTANTS import *
# for i in range(10):
#     print(i)
#     time.sleep(5)

print('FFnfjnvfdjvndkfv'[10:])